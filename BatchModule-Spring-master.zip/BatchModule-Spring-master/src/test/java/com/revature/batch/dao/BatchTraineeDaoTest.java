package com.revature.batch.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class BatchTraineeDaoTest {

	@InjectMocks
	private BatchTraineeDaoImpl batchTraineeDao;
	
	@Test
	void testAddTraineeIntoBatch() {
		
		
		fail("Not yet implemented");
	}

}
