package com.revature.batch.dto;

import java.util.List;

import lombok.Data;

@Data
public class BatchTraineeListDto {

	private List<BatchTraineeDto> batchTraineeList;
}
