package com.revature.batch.model;

import lombok.Data;

@Data
public class Day {
	private int id;
	private String day;
}
