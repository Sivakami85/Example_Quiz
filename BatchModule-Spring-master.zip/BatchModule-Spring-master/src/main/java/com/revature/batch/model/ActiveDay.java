package com.revature.batch.model;

import lombok.Data;

@Data
public class ActiveDay {
	private int dayId;
}
