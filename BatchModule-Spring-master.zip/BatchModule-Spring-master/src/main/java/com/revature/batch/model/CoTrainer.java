package com.revature.batch.model;

import lombok.Data;

@Data
public class CoTrainer {
	private int trainerId;
}
