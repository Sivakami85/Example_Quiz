package com.revature.revaturequiz;

public class ServiceDAOJunit {
	
//	private QuizService serviceObj = new QuizServiceImpl(new QuizDAOImpl(new ConnectionUtil())); 
	
//	@Before
//	public void init() {
//		serviceObj = new QuizServiceImpl(new QuizDAOImpl());
//	}
	
	
//	@Test
//	public void testFindAllQuizzes() throws ServiceException
//	{
//		List<QuizResponseDTO> quizRes = serviceObj.findAllQuizzes();
//		quizRes.forEach(
//				(quiz) ->{
//					System.out.println(quiz);
//				}
//				);
//	}
}
