package com.revature.revaturequiz.model;

import lombok.Data;

@Data
public class Level {
	private Integer id;
	private String levelName;
	private String description;
}
