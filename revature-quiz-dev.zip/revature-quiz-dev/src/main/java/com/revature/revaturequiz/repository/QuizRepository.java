package com.revature.revaturequiz.repository;

import org.springframework.stereotype.Repository;


@Repository
public interface QuizRepository {
//	extends JpaRepository<Quiz, Long>
//	@Query(value="SELECT name,tags,activity_point FROM quizzes",nativeQuery=true)
//	List<Quiz> findAllQuizzes();
//	@Query(value="INSERT INTO quizzes()",nativeQuery=true)
//	public int addQuiz();
}
