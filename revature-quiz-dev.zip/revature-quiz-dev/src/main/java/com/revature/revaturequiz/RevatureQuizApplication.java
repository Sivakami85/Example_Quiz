package com.revature.revaturequiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevatureQuizApplication {
	
	  public static void main(String[] args) {
	  SpringApplication.run(RevatureQuizApplication.class, args); 
	  }
}