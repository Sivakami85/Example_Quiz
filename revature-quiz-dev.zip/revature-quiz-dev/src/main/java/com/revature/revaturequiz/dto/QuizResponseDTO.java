package com.revature.revaturequiz.dto;

import com.revature.revaturequiz.model.Quiz;

import lombok.Data;

@Data
public class QuizResponseDTO {
	private Quiz quiz;
}